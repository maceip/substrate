# 100 trending GitHub repos — 10 languages × top 10 (2026-06-08)

*Reconstruction of daily trending: top-starred repos with push activity in the last 2 days, per language, via the GitHub API. The trending page has no official API; this is the faithful equivalent.*


## Python

- **public-apis/public-apis** (440,257★) — A collective list of free APIs  
  https://github.com/public-apis/public-apis
- **EbookFoundation/free-programming-books** (389,891★) — :books: Freely available programming books  
  https://github.com/EbookFoundation/free-programming-books
- **NousResearch/hermes-agent** (187,270★) — The agent that grows with you  
  https://github.com/NousResearch/hermes-agent
- **Significant-Gravitas/AutoGPT** (184,848★) — AutoGPT is the vision of accessible AI for everyone, to use and to build on. Our mission is to provi  
  https://github.com/Significant-Gravitas/AutoGPT
- **huggingface/transformers** (161,416★) — 🤗 Transformers: the model-definition framework for state-of-the-art machine learning models in text,  
  https://github.com/huggingface/transformers
- **langflow-ai/langflow** (149,417★) — Langflow is a powerful tool for building and deploying AI-powered agents and workflows.  
  https://github.com/langflow-ai/langflow
- **anthropics/skills** (148,019★) — Public repository for Agent Skills  
  https://github.com/anthropics/skills
- **langchain-ai/langchain** (138,827★) — The agent engineering platform.  
  https://github.com/langchain-ai/langchain
- **Comfy-Org/ComfyUI** (116,214★) — The most powerful and modular diffusion model GUI, api and backend with a graph/nodes interface.  
  https://github.com/Comfy-Org/ComfyUI
- **github/spec-kit** (110,510★) — 💫 Toolkit to help you get started with Spec-Driven Development  
  https://github.com/github/spec-kit

## JavaScript

- **facebook/react** (245,668★) — The library for web and native user interfaces.  
  https://github.com/facebook/react
- **affaan-m/ECC** (210,722★) — The agent harness performance optimization system. Skills, instincts, memory, security, and research  
  https://github.com/affaan-m/ECC
- **Snailclimb/JavaGuide** (156,221★) — Java 面试 & 后端通用面试指南，覆盖计算机基础、数据库、分布式、高并发、系统设计与 AI 应用开发  
  https://github.com/Snailclimb/JavaGuide
- **vercel/next.js** (139,893★) — The React Framework  
  https://github.com/vercel/next.js
- **nodejs/node** (117,703★) — Node.js JavaScript runtime ✨🐢🚀✨  
  https://github.com/nodejs/node
- **mrdoob/three.js** (112,897★) — JavaScript 3D Library.  
  https://github.com/mrdoob/three.js
- **mui/material-ui** (98,389★) — Material UI: Comprehensive React component library that implements Google's Material Design. Free fo  
  https://github.com/mui/material-ui
- **louislam/uptime-kuma** (87,774★) — A fancy self-hosted monitoring tool  
  https://github.com/louislam/uptime-kuma
- **sveltejs/svelte** (87,150★) — web development for the rest of us  
  https://github.com/sveltejs/svelte
- **webpack/webpack** (65,786★) — A bundler for javascript and friends. Packs many modules into a few bundled assets. Code Splitting a  
  https://github.com/webpack/webpack

## TypeScript

- **freeCodeCamp/freeCodeCamp** (446,432★) — freeCodeCamp.org's open-source codebase and curriculum. Learn math, programming, and computer scienc  
  https://github.com/freeCodeCamp/freeCodeCamp
- **openclaw/openclaw** (377,640★) — Your own personal AI assistant. Any OS. Any Platform. The lobster way. 🦞  
  https://github.com/openclaw/openclaw
- **nilbuild/developer-roadmap** (356,559★) — Interactive roadmaps, guides and other educational content to help developers grow in their careers.  
  https://github.com/nilbuild/developer-roadmap
- **n8n-io/n8n** (191,617★) — Fair-code workflow automation platform with native AI capabilities. Combine visual building with cus  
  https://github.com/n8n-io/n8n
- **microsoft/vscode** (186,071★) — Visual Studio Code  
  https://github.com/microsoft/vscode
- **anomalyco/opencode** (171,656★) — The open source coding agent.  
  https://github.com/anomalyco/opencode
- **langgenius/dify** (144,437★) — Production-ready platform for agentic workflow development.  
  https://github.com/langgenius/dify
- **firecrawl/firecrawl** (130,270★) — The API to search, scrape, and interact with the web at scale. 🔥  
  https://github.com/firecrawl/firecrawl
- **excalidraw/excalidraw** (124,894★) — Virtual whiteboard for sketching hand-drawn like diagrams  
  https://github.com/excalidraw/excalidraw
- **clash-verge-rev/clash-verge-rev** (124,123★) — A modern GUI client based on Tauri, designed to run in Windows, macOS and Linux for tailored proxy e  
  https://github.com/clash-verge-rev/clash-verge-rev

## Java

- **iluwatar/java-design-patterns** (94,103★) — Design patterns implemented in Java  
  https://github.com/iluwatar/java-design-patterns
- **elastic/elasticsearch** (76,897★) — Free and Open Source, Distributed, RESTful Search Engine  
  https://github.com/elastic/elasticsearch
- **NationalSecurityAgency/ghidra** (69,373★) — Ghidra is a software reverse engineering (SRE) framework  
  https://github.com/NationalSecurityAgency/ghidra
- **TheAlgorithms/Java** (65,798★) — All Algorithms implemented in Java  
  https://github.com/TheAlgorithms/Java
- **spring-projects/spring-framework** (60,012★) — Spring Framework  
  https://github.com/spring-projects/spring-framework
- **google/guava** (51,478★) — Google core libraries for Java  
  https://github.com/google/guava
- **dbeaver/dbeaver** (50,466★) — Free universal database tool and SQL client  
  https://github.com/dbeaver/dbeaver
- **ReactiveX/RxJava** (48,235★) — RxJava – Reactive Extensions for the JVM – a library for composing asynchronous and event-based prog  
  https://github.com/ReactiveX/RxJava
- **apache/dubbo** (41,520★) — The java implementation of Apache Dubbo. An RPC and microservice framework.  
  https://github.com/apache/dubbo
- **halo-dev/halo** (38,919★) — Halo 是一款强大易用的开源建站工具，从个人博客、知识库，到企业官网、在线商城，Halo 都能助您轻松实现，一站式满足您的多样化建站需求。  
  https://github.com/halo-dev/halo

## C++

- **tensorflow/tensorflow** (195,608★) — An Open Source Machine Learning Framework for Everyone  
  https://github.com/tensorflow/tensorflow
- **facebook/react-native** (125,955★) — A framework for building native applications using React  
  https://github.com/facebook/react-native
- **electron/electron** (121,568★) — :electron: Build cross-platform desktop apps with JavaScript, HTML, and CSS  
  https://github.com/electron/electron
- **ggml-org/llama.cpp** (115,619★) — LLM inference in C/C++  
  https://github.com/ggml-org/llama.cpp
- **godotengine/godot** (112,260★) — Godot Engine – Multi-platform 2D and 3D game engine  
  https://github.com/godotengine/godot
- **bitcoin/bitcoin** (89,331★) — Bitcoin Core integration/staging tree  
  https://github.com/bitcoin/bitcoin
- **opencv/opencv** (88,352★) — Open Source Computer Vision Library  
  https://github.com/opencv/opencv
- **ocornut/imgui** (73,737★) — Dear ImGui: Bloat-free Graphical User interface for C++ with minimal dependencies  
  https://github.com/ocornut/imgui
- **protocolbuffers/protobuf** (71,328★) — Protocol Buffers - Google's data interchange format  
  https://github.com/protocolbuffers/protobuf
- **LadybirdBrowser/ladybird** (63,961★) — Truly independent web browser  
  https://github.com/LadybirdBrowser/ladybird

## C#

- **microsoft/PowerToys** (133,940★) — Microsoft PowerToys is a collection of utilities that supercharge productivity and customization on   
  https://github.com/microsoft/PowerToys
- **2dust/v2rayN** (108,384★) — A GUI client for Windows, Linux and macOS, support Xray and sing-box and others  
  https://github.com/2dust/v2rayN
- **jellyfin/jellyfin** (53,048★) — The Free Software Media System - Server Backend & API  
  https://github.com/jellyfin/jellyfin
- **files-community/Files** (43,827★) — A modern file manager that helps users organize their files and folders.  
  https://github.com/files-community/Files
- **dotnet/aspnetcore** (38,018★) — ASP.NET Core is a cross-platform .NET framework for building modern cloud-based web applications on   
  https://github.com/dotnet/aspnetcore
- **AvaloniaUI/Avalonia** (30,940★) — Develop Desktop, Embedded, Mobile and WebAssembly apps with C# and XAML. The future of .NET UI  
  https://github.com/AvaloniaUI/Avalonia
- **microsoft/semantic-kernel** (28,079★) — Integrate cutting-edge LLM technology quickly and easily into your apps  
  https://github.com/microsoft/semantic-kernel
- **Devolutions/UniGetUI** (24,317★) — UniGetUI: The Graphical Interface for your package managers. Could be terribly described as a packag  
  https://github.com/Devolutions/UniGetUI
- **QL-Win/QuickLook** (23,694★) — Bring macOS “Quick Look” feature to Windows  
  https://github.com/QL-Win/QuickLook
- **dotnet/maui** (23,264★) — .NET MAUI is the .NET Multi-platform App UI, a framework for building native device applications spa  
  https://github.com/dotnet/maui

## Go

- **avelino/awesome-go** (174,934★) — A curated list of awesome Go frameworks, libraries and software  
  https://github.com/avelino/awesome-go
- **ollama/ollama** (173,612★) — Get up and running with Kimi-K2.6, GLM-5.1, MiniMax, DeepSeek, gpt-oss, Qwen, Gemma and other models  
  https://github.com/ollama/ollama
- **golang/go** (134,633★) — The Go programming language  
  https://github.com/golang/go
- **kubernetes/kubernetes** (122,891★) — Production-Grade Container Scheduling and Management  
  https://github.com/kubernetes/kubernetes
- **gohugoio/hugo** (88,465★) — The world’s fastest framework for building websites.  
  https://github.com/gohugoio/hugo
- **syncthing/syncthing** (85,143★) — Open Source Continuous File Synchronization  
  https://github.com/syncthing/syncthing
- **junegunn/fzf** (80,927★) — :cherry_blossom: A command-line fuzzy finder  
  https://github.com/junegunn/fzf
- **jesseduffield/lazygit** (79,117★) — simple terminal UI for git commands  
  https://github.com/jesseduffield/lazygit
- **caddyserver/caddy** (73,243★) — Fast and extensible multi-platform HTTP/1-2-3 web server with automatic HTTPS  
  https://github.com/caddyserver/caddy
- **moby/moby** (71,641★) — The Moby Project - a collaborative project for the container ecosystem to assemble container-based s  
  https://github.com/moby/moby

## C

- **torvalds/linux** (235,854★) — Linux kernel source tree  
  https://github.com/torvalds/linux
- **netdata/netdata** (79,089★) — The fastest path to AI-powered full stack observability, even for lean teams.  
  https://github.com/netdata/netdata
- **redis/redis** (74,754★) — For developers, who are building real-time data-driven applications, Redis is the preferred, fastest  
  https://github.com/redis/redis
- **obsproject/obs-studio** (73,015★) — OBS Studio - Free and open source software for live streaming and screen recording  
  https://github.com/obsproject/obs-studio
- **FFmpeg/FFmpeg** (60,895★) — Mirror of https://git.ffmpeg.org/ffmpeg.git  
  https://github.com/FFmpeg/FFmpeg
- **tmux/tmux** (46,390★) — tmux source code  
  https://github.com/tmux/tmux
- **curl/curl** (42,084★) — A command line tool and library for transferring data with URL syntax, supporting DICT, FILE, FTP, F  
  https://github.com/curl/curl
- **php/php-src** (40,139★) — The PHP Interpreter  
  https://github.com/php/php-src
- **mpv-player/mpv** (35,501★) — 🎥 Command line media player  
  https://github.com/mpv-player/mpv
- **jqlang/jq** (34,834★) — Command-line JSON processor  
  https://github.com/jqlang/jq

## Rust

- **ultraworkers/claw-code** (193,489★) — An agent-managed museum exhibit, built in Rust with Gajae-Code / LazyCodex — developed and maintaine  
  https://github.com/ultraworkers/claw-code
- **rust-lang/rust** (113,715★) — Empowering everyone to build reliable and efficient software.  
  https://github.com/rust-lang/rust
- **tauri-apps/tauri** (107,625★) — Build smaller, faster, and more secure desktop and mobile applications with a web frontend.  
  https://github.com/tauri-apps/tauri
- **denoland/deno** (107,012★) — A modern runtime for JavaScript and TypeScript.  
  https://github.com/denoland/deno
- **farion1231/cc-switch** (95,143★) — A cross-platform desktop All-in-One assistant for Claude Code, Codex, OpenCode, OpenClaw, Gemini CLI  
  https://github.com/farion1231/cc-switch
- **oven-sh/bun** (92,940★) — Incredibly fast JavaScript runtime, bundler, test runner, and package manager – all in one  
  https://github.com/oven-sh/bun
- **openai/codex** (89,658★) — Lightweight coding agent that runs in your terminal  
  https://github.com/openai/codex
- **astral-sh/uv** (86,143★) — An extremely fast Python package and project manager, written in Rust.  
  https://github.com/astral-sh/uv
- **zed-industries/zed** (84,795★) — Code at the speed of thought – Zed is a high-performance, multiplayer code editor from the creators   
  https://github.com/zed-industries/zed
- **unionlabs/union** (73,982★) — The trust-minimized, zero-knowledge bridging protocol, designed for censorship resistance, extremely  
  https://github.com/unionlabs/union

## PHP

- **danielmiessler/SecLists** (71,441★) — SecLists is the security tester's companion. It's a collection of multiple types of lists used durin  
  https://github.com/danielmiessler/SecLists
- **nextcloud/server** (35,698★) — ☁️ Nextcloud server, a safe home for all your data  
  https://github.com/nextcloud/server
- **laravel/framework** (34,755★) — Laravel is a web application framework with expressive, elegant syntax.  
  https://github.com/laravel/framework
- **symfony/symfony** (31,062★) — The Symfony PHP framework  
  https://github.com/symfony/symfony
- **filamentphp/filament** (31,038★) — A powerful open-source UI framework for Laravel • Build and ship apps & admin panels fast with Livew  
  https://github.com/filamentphp/filament
- **composer/composer** (29,449★) — Dependency Manager for PHP  
  https://github.com/composer/composer
- **bagisto/bagisto** (27,077★) — Free and open source laravel eCommerce platform  
  https://github.com/bagisto/bagisto
- **firefly-iii/firefly-iii** (23,659★) — Firefly III: a personal finances manager  
  https://github.com/firefly-iii/firefly-iii
- **guzzle/guzzle** (23,450★) — Guzzle, an extensible PHP HTTP client  
  https://github.com/guzzle/guzzle
- **matomo-org/matomo** (21,578★) — Empowering People Ethically 🚀 — Matomo is hiring! Join us → https://matomo.org/jobs Matomo is the le  
  https://github.com/matomo-org/matomo