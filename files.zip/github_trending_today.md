# GitHub Trending Today — 10 languages × top 10 (live scrape, 2026-06-08)

*Scraped directly from github.com/trending/<lang>?since=daily, unauthenticated. 'stars today' = stars gained today.*


## Python

- **mvanhorn/last30days-skill** (+3,558 today) — AI agent skill that researches any topic across Reddit, X, YouTube, HN, Polymarket, and the web  
  https://github.com/mvanhorn/last30days-skill
- **RyanCodrai/turbovec** (+1,730 today) — A vector index built on TurboQuant, written in Rust with Python bindings  
  https://github.com/RyanCodrai/turbovec
- **google/skills** (+481 today) — Agent Skills for Google products and technologies  
  https://github.com/google/skills
- **Panniantong/Agent-Reach** (+796 today) — Give your AI agent eyes to see the entire internet. Read & search Twitter, Reddit, YouTube, Git  
  https://github.com/Panniantong/Agent-Reach
- **Andyyyy64/whichllm** (+103 today) — Find the local LLM that actually runs and performs best on your hardware. Ranked by real, recen  
  https://github.com/Andyyyy64/whichllm
- **MemPalace/mempalace** (+237 today) — The best-benchmarked open-source AI memory system. And it's free.  
  https://github.com/MemPalace/mempalace
- **roboflow/supervision** (+1,140 today) — We write your reusable computer vision tools. 💜  
  https://github.com/roboflow/supervision
- **luongnv89/claude-howto** (+393 today) — A visual, example-driven guide to Claude Code — from basic concepts to advanced agents, with co  
  https://github.com/luongnv89/claude-howto
- **alistaitsacle/free-llm-api-keys** (+143 today) — Free LLM API keys for GPT-5.5, Claude, DeepSeek, Gemini, Grok — copy, paste, use. Updated 3-5x   
  https://github.com/alistaitsacle/free-llm-api-keys
- **magenta/magenta-realtime** (+86 today) — Magenta RealTime 2: An Open-Weights Live Music Model  
  https://github.com/magenta/magenta-realtime

## Javascript

- **santifer/career-ops** (+477 today) — AI-powered job search system built on Claude Code. 14 skill modes, Go dashboard, PDF generation  
  https://github.com/santifer/career-ops
- **openai/plugins** (+296 today) — OpenAI Plugins  
  https://github.com/openai/plugins
- **coreyhaines31/marketingskills** (+183 today) — Marketing skills for Claude Code and AI agents. CRO, copywriting, SEO, analytics, and growth en  
  https://github.com/coreyhaines31/marketingskills
- **sveltejs/svelte** (+44 today) — web development for the rest of us  
  https://github.com/sveltejs/svelte
- **chinese-poetry/chinese-poetry** (+32 today) — The most comprehensive database of Chinese poetry 🧶最全中华古诗词数据库, 唐宋两朝近一万四千古诗人, 接近5.5万首唐诗加26万宋诗. 两  
  https://github.com/chinese-poetry/chinese-poetry
- **tradesdontlie/tradingview-mcp** (+31 today) — AI-assisted TradingView chart analysis — connect Claude Code to your TradingView Desktop for pe  
  https://github.com/tradesdontlie/tradingview-mcp
- **hmjz100/LinkSwift** (+53 today) — 一个基于 JavaScript 的网盘文件下载地址获取工具。基于【网盘直链下载助手】修改 ，支持 百度网盘 / 阿里云盘 / 中国移动云盘 / 天翼云盘 / 迅雷云盘 / 夸克网盘 / UC  
  https://github.com/hmjz100/LinkSwift
- **fastify/fastify** (+23 today) — Fast and low overhead web framework, for Node.js  
  https://github.com/fastify/fastify
- **webpack/webpack** (+18 today) — A bundler for javascript and friends. Packs many modules into a few bundled assets. Code Splitt  
  https://github.com/webpack/webpack
- **y13sint/FreeQwenApi** (+13 today) — Локальный API-прокси для Qwen AI с поддержкой сохранения контекста диалогов и управления сессия  
  https://github.com/y13sint/FreeQwenApi

## Typescript

- **refactoringhq/tolaria** (+649 today) — Desktop app to manage markdown knowledge bases  
  https://github.com/refactoringhq/tolaria
- **danielmiessler/Personal_AI_Infrastructure** (+121 today) — Agentic AI Infrastructure for magnifying HUMAN capabilities.  
  https://github.com/danielmiessler/Personal_AI_Infrastructure
- **CopilotKit/CopilotKit** (+398 today) — The Frontend Stack for Agents & Generative UI. React, Angular, Mobile, Slack, and more. Makers   
  https://github.com/CopilotKit/CopilotKit
- **lfnovo/open-notebook** (+894 today) — An Open Source implementation of Notebook LM with more flexibility and features  
  https://github.com/lfnovo/open-notebook
- **ibelick/ui-skills** (+258 today) — Skills for Design Engineers  
  https://github.com/ibelick/ui-skills
- **Makisuo/maple** (+159 today) — OpenTelemetry observability platform  
  https://github.com/Makisuo/maple
- **danny-avila/LibreChat** (+139 today) — Enhanced ChatGPT Clone: Features Agents, MCP, Skills, DeepSeek, Anthropic, AWS, OpenAI, Respons  
  https://github.com/danny-avila/LibreChat
- **heygen-com/hyperframes** (+415 today) — Write HTML. Render video. Built for agents.  
  https://github.com/heygen-com/hyperframes
- **Crosstalk-Solutions/project-nomad** (+536 today) — Project N.O.M.A.D, is a self-contained, offline survival computer packed with critical tools, k  
  https://github.com/Crosstalk-Solutions/project-nomad
- **vitejs/vite** (+32 today) — Next generation frontend tooling. It's fast!  
  https://github.com/vitejs/vite

## Java

- **jenkinsci/jenkins** (+19 today) — Jenkins automation server  
  https://github.com/jenkinsci/jenkins
- **opensearch-project/OpenSearch** (+28 today) — 🔎 Open source distributed and RESTful search engine.  
  https://github.com/opensearch-project/OpenSearch
- **termux/termux-app** (+40 today) — Termux - a terminal emulator application for Android OS extendible by variety of packages.  
  https://github.com/termux/termux-app
- **elastic/elasticsearch** (+26 today) — Free and Open Source, Distributed, RESTful Search Engine  
  https://github.com/elastic/elasticsearch
- **Anuken/Mindustry** (+20 today) — The automation tower defense RTS  
  https://github.com/Anuken/Mindustry
- **woheller69/FreeDroidWarn** (+20 today) —   
  https://github.com/woheller69/FreeDroidWarn
- **SeleniumHQ/selenium** (+10 today) — A browser automation framework and ecosystem.  
  https://github.com/SeleniumHQ/selenium
- **OpenAPITools/openapi-generator** (+8 today) — OpenAPI Generator allows generation of API client libraries (SDK generation), server stubs, doc  
  https://github.com/OpenAPITools/openapi-generator
- **cabaletta/baritone** (+0 today) — google maps for block game  
  https://github.com/cabaletta/baritone
- **kunal-kushwaha/DSA-Bootcamp-Java** (+17 today) — This repository consists of the code samples, assignments, and notes for the Java data structur  
  https://github.com/kunal-kushwaha/DSA-Bootcamp-Java

## C++

- **SerenityOS/serenity** (+22 today) — The Serenity Operating System 🐞  
  https://github.com/SerenityOS/serenity
- **opencv/opencv** (+447 today) — Open Source Computer Vision Library  
  https://github.com/opencv/opencv
- **Fincept-Corporation/FinceptTerminal** (+196 today) — FinceptTerminal is a modern finance application offering advanced market analytics, investment   
  https://github.com/Fincept-Corporation/FinceptTerminal
- **ggml-org/llama.cpp** (+492 today) — LLM inference in C/C++  
  https://github.com/ggml-org/llama.cpp
- **xbmc/xbmc** (+19 today) — Kodi is an award-winning free and open source home theater/media center software and entertainm  
  https://github.com/xbmc/xbmc
- **praydog/REFramework** (+7 today) — Mod loader, scripting platform, and VR support for all RE Engine games  
  https://github.com/praydog/REFramework
- **MaaAssistantArknights/MaaAssistantArknights** (+23 today) — 《明日方舟》小助手，全日常一键长草！| A one-click tool for the daily tasks of Arknights, supporting all clients.  
  https://github.com/MaaAssistantArknights/MaaAssistantArknights
- **78/xiaozhi-esp32** (+51 today) — An MCP-based chatbot | 一个基于MCP的聊天机器人  
  https://github.com/78/xiaozhi-esp32
- **openscad/openscad** (+6 today) — OpenSCAD - The Programmers Solid 3D CAD Modeller  
  https://github.com/openscad/openscad
- **MAZHARMIK/Interview_DS_Algo** (+44 today) — Super Repository for Coding Interview Preperation  
  https://github.com/MAZHARMIK/Interview_DS_Algo

## C#

- **jellyfin/jellyfin** (+43 today) — The Free Software Media System - Server Backend & API  
  https://github.com/jellyfin/jellyfin
- **hellzerg/optimizer** (+4 today) — The finest Windows Optimizer  
  https://github.com/hellzerg/optimizer
- **JosefNemec/Playnite** (+20 today) — Video game library manager with support for wide range of 3rd party libraries and game emulatio  
  https://github.com/JosefNemec/Playnite
- **Radarr/Radarr** (+7 today) — Movie organizer/manager for usenet and torrent users.  
  https://github.com/Radarr/Radarr
- **dotnet/msbuild** (+0 today) — The Microsoft Build Engine (MSBuild) is the build platform for .NET and Visual Studio.  
  https://github.com/dotnet/msbuild
- **k1tbyte/Wand-Enhancer** (+15 today) — Advanced UX and interoperability extension for Wand (WeMod) app  
  https://github.com/k1tbyte/Wand-Enhancer
- **BeyondDimension/SteamTools** (+25 today) — 🛠「Watt Toolkit」是一个开源跨平台的多功能 Steam 工具箱。  
  https://github.com/BeyondDimension/SteamTools
- **PunishXIV/Splatoon** (+0 today) — An accessibility tool to assist in gameplay and compensate for human imperfections.  
  https://github.com/PunishXIV/Splatoon
- **microsoft/PowerToys** (+55 today) — Microsoft PowerToys is a collection of utilities that supercharge productivity and customizatio  
  https://github.com/microsoft/PowerToys
- **SubtitleEdit/subtitleedit** (+9 today) — the subtitle editor :)  
  https://github.com/SubtitleEdit/subtitleedit

## Go

- **mvanhorn/cli-printing-press** (+89 today) — Every API has a secret identity. This finds it, absorbs every feature from every competing tool  
  https://github.com/mvanhorn/cli-printing-press
- **Wei-Shaw/sub2api** (+440 today) — Sub2API is an open-source relay platform that unifies Claude, OpenAI, Gemini, and Antigravity s  
  https://github.com/Wei-Shaw/sub2api
- **terrastruct/d2** (+56 today) — D2 is a modern diagram scripting language that turns text to diagrams.  
  https://github.com/terrastruct/d2
- **aquasecurity/trivy** (+78 today) — Find vulnerabilities, misconfigurations, secrets, SBOM in containers, Kubernetes, code reposito  
  https://github.com/aquasecurity/trivy
- **passteque/gluetun** (+12 today) — VPN client in a thin Docker container for multiple VPN providers, written in Go, and using Open  
  https://github.com/passteque/gluetun
- **asheshgoplani/agent-deck** (+15 today) — Terminal session manager for AI coding agents. One TUI for Claude, Gemini, OpenCode, Codex, and  
  https://github.com/asheshgoplani/agent-deck
- **mvanhorn/printing-press-library** (+17 today) — Official library of CLIs generated by the CLI Printing Press. Endorsed, tested, and community-c  
  https://github.com/mvanhorn/printing-press-library
- **danielmiessler/Fabric** (+45 today) — Fabric is an open-source framework for augmenting humans using AI. It provides a modular system  
  https://github.com/danielmiessler/Fabric
- **rclone/rclone** (+64 today) — "rsync for cloud storage" - Google Drive, S3, Dropbox, Backblaze B2, One Drive, Swift, Hubic, W  
  https://github.com/rclone/rclone
- **ethereum/go-ethereum** (+20 today) — Go implementation of the Ethereum protocol  
  https://github.com/ethereum/go-ethereum

## C

- **dayanch96/YTMusicUltimate** (+6 today) — The best tweak for YouTube Music iOS.  
  https://github.com/dayanch96/YTMusicUltimate
- **jtenniswood/espcontrol** (+17 today) — Esphome based smart home control panel  
  https://github.com/jtenniswood/espcontrol
- **libsdl-org/SDL** (+14 today) — Simple DirectMedia Layer  
  https://github.com/libsdl-org/SDL
- **nginx/nginx** (+25 today) — The official NGINX Open Source repository.  
  https://github.com/nginx/nginx
- **meshcore-dev/MeshCore** (+7 today) — A new lightweight, hybrid routing mesh protocol for packet radios  
  https://github.com/meshcore-dev/MeshCore
- **apache/httpd** (+14 today) — Mirror of Apache HTTP Server. Issues: http://issues.apache.org  
  https://github.com/apache/httpd
- **git/git** (+22 today) — Git Source Code Mirror - This is a publish-only repository but pull requests can be turned into  
  https://github.com/git/git
- **DeusData/codebase-memory-mcp** (+28 today) — High-performance code intelligence MCP server. Indexes codebases into a persistent knowledge gr  
  https://github.com/DeusData/codebase-memory-mcp
- **acidanthera/OpenCorePkg** (+11 today) — OpenCore bootloader  
  https://github.com/acidanthera/OpenCorePkg
- **betaflight/betaflight** (+4 today) — Open Source Flight Controller Firmware  
  https://github.com/betaflight/betaflight

## Rust

- **aaif-goose/goose** (+699 today) — an open source, extensible AI agent that goes beyond code suggestions - install, execute, edit,  
  https://github.com/aaif-goose/goose
- **hyperlight-dev/hyperlight** (+24 today) — Hyperlight is a lightweight Virtual Machine Manager (VMM) designed to be embedded within applic  
  https://github.com/hyperlight-dev/hyperlight
- **microsoft/pg_durable** (+356 today) — PostgreSQL in-database durable execution  
  https://github.com/microsoft/pg_durable
- **microsoft/mxc** (+65 today) — Policy-driven, layered isolation and containment  
  https://github.com/microsoft/mxc
- **GyulyVGC/sniffnet** (+640 today) — Comfortably monitor your Internet traffic 🕵️‍♂️  
  https://github.com/GyulyVGC/sniffnet
- **denoland/deno** (+34 today) — A modern runtime for JavaScript and TypeScript.  
  https://github.com/denoland/deno
- **zhom/donutbrowser** (+21 today) — Simple Yet Powerful Anti-Detect Browser 🍩  
  https://github.com/zhom/donutbrowser
- **slint-ui/slint** (+12 today) — Slint is an open-source declarative GUI toolkit to build native user interfaces for Rust, C++,   
  https://github.com/slint-ui/slint
- **qdrant/qdrant** (+37 today) — Qdrant - High-performance, massive-scale Vector Database and Vector Search Engine for the next   
  https://github.com/qdrant/qdrant
- **ast-grep/ast-grep** (+28 today) — ⚡A CLI tool for code structural search, lint and rewriting. Written in Rust  
  https://github.com/ast-grep/ast-grep

## Php

- **DenverCoder1/readme-typing-svg** (+8 today) — ⚡ Dynamically generated, customizable SVG that gives the appearance of typing and deleting text  
  https://github.com/DenverCoder1/readme-typing-svg
- **filamentphp/filament** (+14 today) — A powerful open-source UI framework for Laravel • Build and ship apps & admin panels fast with   
  https://github.com/filamentphp/filament
- **stripe/stripe-php** (+0 today) — PHP library for the Stripe API.  
  https://github.com/stripe/stripe-php
- **coollabsio/coolify** (+57 today) — An open-source, self-hostable PaaS alternative to Vercel, Heroku & Netlify that lets you easily  
  https://github.com/coollabsio/coolify
- **cedar2025/Xboard** (+4 today) — High-performance panel based on V2board secondary development supporting new protocols and new   
  https://github.com/cedar2025/Xboard
- **Automattic/jetpack** (+0 today) — Security, performance, marketing, and design tools — Jetpack is made by WordPress experts to ma  
  https://github.com/Automattic/jetpack
- **joomla/joomla-cms** (+0 today) — Home of the Joomla! Content Management System  
  https://github.com/joomla/joomla-cms
- **easychen/opc-methodology** (+10 today) — 《一人企业方法论》第二版，也适合做其他副业（比如自媒体、电商、数字商品）的非技术人群。  
  https://github.com/easychen/opc-methodology
- **openmediavault/openmediavault** (+5 today) — openmediavault is the next generation network attached storage (NAS) solution based on Debian L  
  https://github.com/openmediavault/openmediavault
- **lizhipay/acg-faka** (+0 today) — 个人发卡源码，发卡系统，二次元发卡系统，二次元发卡源码，发卡程序，动漫发卡，PHP发卡源码，异次元发卡  
  https://github.com/lizhipay/acg-faka