# NURSERY BLOCKS — Next-js-Boilerplate (ixartz)
Divined from: Clerk + Drizzle + Arcjet + logtape + t3-env + next-intl + Sentry

Each block is a thing every new Next.js project rebuilds. Nursery = the thinnest real version.
Graduated = what it becomes when the project scales into needing it.

---

## B1 — Protected Route Group
What it is: the `(auth)` layout wrapper that gates everything inside it to signed-in users.
What it gives you: drop a route inside `(auth)/` and it's protected, automatically.
Nursery: ClerkProvider wrapping children, redirect to /sign-in if no session. ~20 lines.
Graduated: role-based access, org/tenant gating, per-route permission checks.

## B2 — Database Adapter
What it is: `src/libs/DB.ts` — one place the DB connection lives, global-cached for hot reload.
What it gives you: `import { db }` from anywhere; swap postgres for sqlite by changing one file.
Nursery: Drizzle + connection string from env, cached in globalThis. ~15 lines.
Graduated: read replicas, connection pooling (PgBouncer), multi-tenant row scoping.

## B3 — Schema Baseline
What it is: `src/models/Schema.ts` — the Drizzle table definitions with the id/createdAt/updatedAt convention baked in.
What it gives you: every table starts with the right shape; the expensive "add timestamps to everything" migration is pre-absorbed.
Nursery: one example table with `serial id`, `timestamp createdAt`, `timestamp updatedAt`. The convention, not the domain tables.
Graduated: add your domain tables following the same convention.

## B4 — Env Validation
What it is: `src/libs/Env.ts` — t3-env + Zod validating every env var at startup, failing loud if one is missing.
What it gives you: the app won't start with a misconfigured secret. No more `undefined` leaking into prod.
Nursery: server + client + shared buckets, the three required vars (Clerk, DB, App URL). ~30 lines.
Graduated: add vars as you add capabilities; the shape stays.

## B5 — Structured Logger
What it is: `src/libs/Logger.ts` — logtape configured once, writing JSON to console dev / Better Stack prod.
What it gives you: `import { Logger }` anywhere; structured logs from day one; swap the sink without touching call sites.
Nursery: console sink only. ~10 lines.
Graduated: Better Stack / Datadog / Sentry sink behind the same interface.

## B6 — Request Guard (rate-limit + shield)
What it is: `src/libs/Arcjet.ts` — a base Arcjet instance applied at the route level, blocking common attacks and rate-limiting by IP.
What it gives you: attach to any API route with one import; the "add rate limiting" change is a one-line addition, not a rewrite.
Nursery: shield-only (blocks common attack patterns), DRY_RUN mode so it logs but doesn't block yet. ~10 lines.
Graduated: LIVE mode, per-route rate-limit rules, bot detection, email validation.

## B7 — Input Validation Shape
What it is: `src/validations/CounterValidation.ts` — Zod schema at the API boundary.
What it gives you: every API route validates its input in one place before it touches the DB; the "add a field" change is one Zod line.
Nursery: one example schema (the counter). The pattern: `z.object({...})` exported and used in the route handler.
Graduated: per-resource schemas, shared types between client and server.

## B8 — i18n Routing
What it is: `src/libs/I18nRouting.ts` + `I18nNavigation.ts` + `[locale]` segment — every route is locale-prefixed from day one.
What it gives you: adding a language later is adding a locale file, not rearchitecting routing.
Nursery: en only, but the `[locale]` wrapper is there. ~20 lines of config.
Graduated: add locale files; Clerk localizations follow automatically.

## B9 — Error Boundary + Observability
What it is: `src/app/global-error.tsx` + `instrumentation.ts` — Sentry wired at the framework level.
What it gives you: unhandled errors are captured from day one; the "add error tracking" change is already made.
Nursery: Sentry DSN from env, global-error page. ~15 lines.
Graduated: per-component error boundaries, session replay, performance tracing.

## B10 — API Route Pattern
What it is: `src/app/api/counter/route.ts` — the canonical shape of a Next.js API route: validate input → check auth → hit DB → return typed response.
What it gives you: every new API route follows the same shape; the expensive-change points (auth check, validation, DB call) each go through their respective blocks above.
Nursery: one working route that composes B1+B2+B4+B6+B7 as the template to copy.
Graduated: middleware chains, response caching, streaming.

---
# THE 3 THINGS THAT ARE NOT DOMAIN BUT ARE ALWAYS REBUILT
(These are the ones nobody thinks of as "blocks" but are in every project)

- **B3 (schema baseline)**: the id/createdAt/updatedAt convention. Every team redecides this. Pre-decide it.
- **B4 (env validation)**: every project ships with missing-env bugs in prod. Pre-wire it.
- **B8 (i18n routing)**: retrofitting i18n onto a routing structure is brutal. The `[locale]` segment is free at day one and catastrophic to add later.

---

# FULL SESSION EXPORT — everything built and decided today

## What the thing is
A **nursery for new projects**: a starting point where the common infrastructure capabilities
every app needs are already there as **ports** (narrow, fixed interfaces) each backed by the
thinnest real implementation, swappable for a heavier one later WITHOUT touching app code on top.
A block is a piece of working capability you build WITH — not an audit tool, not Scratch,
not a general compiler. The blocks are INVISIBLE: composed beneath attention, not assembled
by hand.

## What a port is (corrected late in session — important)
A port is NOT a capability name (not "auth"). A port is the seam where a change forces the
data/schema to change in a LARGE WAY — routed through one chokepoint to contain the ripple.
The port is defined by what data-change it absorbs. The blocks that consume each port's data
are MANY; those are the real reuse surface the 100 repos reveal.

## The four papers = life in the ports (the linchpin)
WITHOUT these, the nursery is just create-react-app — frozen at day 1.
- **MOSS**: port behavior lives in CODE not prose. Prose drifts under context compression.
- **AEvo**: agents TIGHTEN ports over time; the contract is protected — only human can loosen.
- **Meta-Agent**: ports compose via boundary contracts; failures attribute local/upstream/structural. (real at ≥2 ports)
- **FoT**: lessons FEDERATE across projects — lesson in repo A travels to repo B automatically. (real at ≥2 projects)
**Project one is the deposit. Papers make project two onward withdraw from it.**

## The freedom principle
No schema early = freedom to explore. But absence of structure = guarantees rot silently
(the mixnet: "users can't dial each other" had nowhere to live → it decayed).
Nursery resolves this: ports are PRE-INSTALLED so you decide nothing early (freedom)
AND expensive changes are pre-absorbed (no rot). Batteries included.

## Key things that went wrong today (avoid repeating)
- Drifted into building an audit/guard framework ("strata") instead of blocks. Inverted the whole idea.
- Four papers kept getting listed as decoration instead of the mechanism.
- "Port" was being used as capability name (auth, DB) not as data-change-chokepoint.
- Kept mirroring my own ideas back instead of pushing.

## What's built
- `blocks/py/` — proof-of-concept: persistence/auth/http-server ports in Python,
  notes app built ONLY against ports, sqlite swap proven with ZERO app-code changes.
- `strata/` — the guard harness (wrong turn, parked, not the product).
- `THE-THING-state-of-play.md` — full design doc.
- `blocks-synthesis.md` — concept synthesis (compiler adjacency, four papers, freedom principle).
- `github_trending_today.{md,json}` — 100 real trending repos, 10 languages × top 10, live-scraped.
- `NURSERY-BLOCKS-nextjs.md` (this file) — first real block derivation from a real repo.

## Next steps in order
1. Run the port-catalog mining brief against my repos (local agent, has filesystem access)
   AND the 100 trending repos — get the debiased catalog with cross-tab (mine vs OSS).
2. Build the nursery template with the CORE ports scaffolded: each as port+adapter, app
   built only against ports, nursery-grade impl behind each, swap-to-graduated proven.
3. Wire the four-paper hooks into the port structure from the start:
   MOSS+AEvo live at port #1; Meta-Agent+FoT hooks present but dormant until ≥2 ports/projects.
4. The "consumer blocks" (what projects build ON TOP of each port's data — the real reuse surface)
   are what the 100 repos actually reveal. Map these per port.

## Open questions (honest, don't pretend solved)
- Does the expensive-change port set cluster small or is it a long tail? (empirical — mine the repos)
- Is authoring a port cheap (afternoon) or hard (research project)? Test on first real one.
- Cross-language: ports travel as shape/spec not code; FoT is the reuse mechanism across languages.
- Graduation trigger: what signal makes the nursery decide to swap a thin impl for the heavy one?
  Organic, not asking me. Candidate: project crossing a usage/scale threshold. Unresolved.

## Files to keep
- `/outputs/THE-THING-state-of-play.md` — the design doc, updated with four-paper integration
- `/outputs/blocks-synthesis.md` — concept synthesis
- `/outputs/github_trending_today.{md,json}` — the 100-repo list
- `/outputs/NURSERY-BLOCKS-nextjs.md` — this file, the first real block derivation

## Credential hygiene (do this tonight)
- Rotate the GitHub PAT you pasted: github.com/settings/tokens
- Revoke the session cookie you pasted: github.com/settings/sessions
