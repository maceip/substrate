# THE THING — state of play (so I don't forget)

## What it is (one paragraph, read this first)
I'm building a **nursery for new projects**: a starting point where the common
infrastructure capabilities every app needs are already there as **ports** — narrow,
fixed interfaces you build against — each backed by the *thinnest real implementation*
to start, swappable for a heavier one later WITHOUT touching the app code on top.
You describe an idea loosely; you build on the ports; the boring expensive plumbing is
pre-wired so you don't re-derive it every project, and so changing it later (new DB, new
auth, new transport) is a one-place swap instead of a rewrite that ripples everywhere.

## What it is NOT (I keep drifting into this — stop)
- NOT an audit tool. NOT a linter. NOT a guard/test framework that scans finished code and
  complains. (That was a wrong turn — the "strata" detour. It inverted the whole idea:
  it subtracted/judged instead of adding working capability. Kill that framing on sight.)
- NOT a visual block language / Scratch. The blocks are INVISIBLE — composed beneath
  attention, not assembled by hand on a canvas.
- NOT a general-purpose intent compiler that turns icons into programs. Scope is real
  infrastructure capabilities, a finite set, derived from real repos.

## The core idea in three moves
1. **Port** = the one narrow interface an expensive-change-type passes through (database,
   auth, transport, etc.). Swap what's behind it; the app on top doesn't change. (Standard
   "ports and adapters" — port = fixed opening, adapter = swappable impl behind it.)
2. **Nursery-grade vs graduated**: each port ships with the lightest real impl (nursery),
   and a heavier real impl it graduates into when the project scales (e.g. auth: local
   creds → OAuth → LDAP; store: in-memory → sqlite → postgres). You don't carry the heavy
   one early (no dragging an LDAP corpse into a hackathon). Graduation happens organically
   as the project grows, NOT by interrogating me with questions.
3. **The capability already exists** — it's implemented across my repos many times. The job
   is EXTRACT it into a reusable port, not invent it. (Proven: built a notes app on
   auth/store/names ports, swapped the store from in-memory → sqlite behind the port with
   ZERO app-code changes. The pattern works.)

## The freedom principle (why this matters, the deepest point)
Having no schema early is a FEATURE — it lets me move freely in the idea space without
mental weight. But the absence of structure is exactly what lets load-bearing guarantees
silently rot (the mixnet case: "users shouldn't dial each other directly" had nowhere to
live, so it decayed into a violation; the schema was never defined so "add naming to all
nodes" became impose-structure-retroactively and left half-converted code). The nursery
resolves the tension: the ports/indirection are PRE-INSTALLED so I decide nothing early
(freedom preserved) AND the expensive change is pre-absorbed later (no rot). Batteries
included, so I don't think about it — but it surfaces only the handful of changes that are
known-expensive, and handles the rest silently.

## THE LINCHPIN: the four papers ARE the value, not decoration
A nursery WITHOUT the four papers is just create-react-app — a frozen starter you outgrow,
the same on day 100 as day 1. The four papers are what turn it from a frozen template into
a thing that GETS BETTER every time you or an agent use it. This is the whole reason to
build it instead of using someone's boilerplate. Do not treat these as add-ons.

The integration, stated as ONE mechanism:
  A port is NOT a static template file. A port is:
    - an INTERFACE with a declared boundary contract        [Meta-Agent: composable]
    - backed by EXECUTABLE behavior, not a prose README     [MOSS: code not docs]
    - that agents continuously TIGHTEN but cannot LOOSEN    [AEvo: protected evolution]
    - reading from + writing to a CROSS-PROJECT store that
      accumulates every lesson ever learned using it        [FoT: the flywheel]
  The nursery is just where these ports live and get assembled. The papers are the LIFE
  in the ports.

Per-paper concrete integration:

- **FoT — the flywheel; the reason this is useful to ME specifically.**
  Each port has a federated insight store. Use the `auth` port in project A, hit a gotcha
  ("OAuth tokens need refresh handling"), and that lesson distills into the port's shared
  store. Start project B, pull the same `auth` port → it ALREADY carries A's lesson, with
  me doing nothing by hand. The port reads from a store that accumulates across every
  project that ever used it. That's why project N+1 is cheaper than N. WITHOUT FoT the
  nursery is identical on day 100 as day 1. Test: did a lesson cross a repo boundary
  without me copying it?

- **AEvo — lets agents improve the ports without me babysitting.**
  Each port has a PROTECTED piece (the contract: what the port guarantees) and an OPEN
  piece (the implementation). Any agent in any project can TIGHTEN a port (add a missed
  case, strengthen the adapter) and it flows back. The agent CANNOT loosen the contract —
  only I can. So every agent touching any project improves my whole port library, safely,
  continuously. WITHOUT AEvo, ports only improve when I manually edit them.

- **MOSS — keeps it real; makes the other two STICK.**
  A port's behavior + contract are EXECUTABLE, not a README describing intent. This is why
  the FoT lessons and AEvo tightenings actually hold instead of decaying into a doc nobody
  reads under context compression. WITHOUT MOSS the accumulated lessons rot. MOSS is the
  glue that makes FoT + AEvo durable.

- **Meta-Agent — lets the ports compose into a real app.**
  Each port declares its boundary contract, so wiring `auth` + `store` + `transport`
  together is checkable and a failure attributes to the right place (this port / the port
  it depends on / the wiring). WITHOUT Meta-Agent, assembling ports is ad-hoc glue every time.

WHAT'S REAL AT EACH STAGE (internalize this — it's the part that confuses):
  - MOSS + AEvo work from port #1, project #1 (a single port can be executable + have a
    protected/open split immediately).
  - Meta-Agent needs ≥2 composed ports to mean anything.
  - FoT needs ≥2 PROJECTS to mean anything — and FoT is the one I care most about. So the
    nursery does NOT show its real value on project one. PROJECT ONE IS THE DEPOSIT. The
    four papers are what make project two onward WITHDRAW from that deposit instead of
    starting over. A nursery without the papers can never do that — frozen at project one
    forever. Build the FoT/Meta-Agent hooks from the start, but don't fake their value at N=1.

## APPROACH: how to create the nursery ports for all the projects
Inputs in hand: `github_trending_today.{md,json}` = 100 real trending repos (10 languages ×
top 10), live-scraped. Plus my own repos (local-agent must mine these — I can't see them).

Step 1 — Derive the PORT CATALOG (debiased):
  For each repo (100 trending + my last-8-months repos), identify the
  expensive-change-types it contains — the things that, if swapped, ripple across the code
  (DB, auth, authz, external-API, transport, config, logging, id-strategy, serialization,
  error-handling, async/jobs, caching, tenancy, schema-versioning, + domain-specific ones
  like attestation / mixnet-transport / blind-token / on-device-inference for my work).
  Aggregate into one catalog. For each port record: what it absorbs, reuse count
  (how many repos have it), nursery-grade impl (thinnest real), graduated impl (heavy real).
  Cross-tab two columns — "in N of MY repos" vs "in M of the trending repos" — to debias:
    - high in both = core, build first
    - high in trending / low in mine = my blind spot
    - high in mine / low in trending = my domain specialty OR idiosyncrasy (flag which)
  Don't cap the count (could be 8, could be 80). Derive from real code, not generic guesses.
  The MATURITY DELTA (ports absent in early/hackathon repos but present in mature ones) =
  the graduation-only set, empirically.

Step 2 — Build the NURSERY TEMPLATE:
  A starting project where the CORE ports (light, high-reuse) are scaffolded as
  port-and-adapter: each port = a narrow interface + nursery-grade adapter behind it.
  The app is built ONLY against ports (never names an impl, never uses bare string literals
  for names — names come from one source). Generalize the proven pattern so adding the Nth
  port is mechanical. Prove each port the same way it was proven once: swap the adapter
  (nursery → graduated) and show app code does NOT change.

Step 3 — Wire the four-paper machinery into the port structure (SEE "THE LINCHPIN"
  section above — this is the core value, not an add-on): MOSS (executable behavior) and
  the protected-evaluator split (AEvo) per port from day one; Meta-Agent composition
  contracts so ports assemble; FoT federated insight store per port so lessons travel
  across projects. Build all four hooks from the start; MOSS+AEvo are live at N=1, while
  Meta-Agent (≥2 ports) and FoT (≥2 projects) only show value as you scale — but the
  STRUCTURE for them must exist from the first port or you can't add it later.

## The one-line north star
A nursery for new projects where the common infrastructure capabilities are pre-wired as
invisible, swappable ports — extracted from real repos, light to start, heavy when you grow
into them — so I build fast and loose on top while the expensive plumbing never has to be
re-derived and never silently rots.

## Honest open questions (don't pretend these are solved)
- Does the expensive-change set cluster cleanly (small catalog) or is it a long tail? —
  answer empirically from the repo mining, not by theorizing.
- Is a port "cheap enough to author per capability" (an afternoon) or a research project? —
  if every port is hard, the flywheel stalls. Test on the first real one.
- Cross-language: a port's CODE can't move between languages, only its SHAPE. So across
  languages a port is a spec you re-realize, and FoT (insight travel) is the reuse mechanism,
  not code reuse. Within one language it's droppable code. Both are fine; know which.
- What triggers graduation (organic, not asking me)? — unresolved; candidate signal is the
  maturity-delta from the mining.
