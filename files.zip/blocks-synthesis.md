# Blocks: a synthesis

*Consolidating one idea across a long session — the "block" as it sits next to a compiler,
as it speeds up building, and as it carries the four papers. Everything below is the concept,
stripped of the side-channels (the repo autopsy, the audit-tool detour, the tooling arguments).*

---

## 1. The core idea, in one line

A **block** is a reusable, implemented application capability you build *with* — named at a
high level ("users can log in," "peers talk privately," "store this durably"), dropped into a
new project, working. The implementation is invisible; you don't see or hand-assemble the
parts. You name intent; the working capability lands.

This is the thing that was wanted from the start, and the thing easy to lose: a block **adds**
(gives you working capability), it does not merely **subtract** (audit what you wrote). An
auditor that scans finished code and complains is the inversion to avoid — it makes more work,
not less. The block's job is acceleration.

## 2. Two grains of block

The session surfaced two kinds, and both are real:

- **Infrastructure blocks** — the capability itself: auth, storage/persistence, transport,
  job queue, pub/sub, caching, config. And, for specialized work: sealed-routing/mixnet,
  attested-execution (TEE), on-device inference, payment rails, unlinkable tokens.
- **Mechanism blocks** — the reusable machinery that makes the infra blocks trustworthy:
  the fail-closed guard, the controlled-substrate runtime, the layering/fitness check.

The mistake to avoid: letting the *mechanism* (the guard) become the product. The guard is a
**thin rider** attached to a block so the block can't be silently misused — it is the
passenger, never the vehicle. Build blocks you create *with*; let each carry a small guard.

## 3. Two layers inside every block (the load-bearing distinction)

| layer | form | role |
|---|---|---|
| **manifest** | text | ambient, ignorable, *non-enforcing*. Names the block, its purpose, the reference it wraps. Safe to ignore — that's why it's allowed to be prose. |
| **guard** | code | load-bearing, *enforcing*. Runs and passes/fails. The contract lives here, never in prose. |

The hard rule, learned the expensive way: **prose never enforces; only code does.** A contract
that lives in a README or a spec doc drifts and gets ignored under context compression. The
only thing that held, repeatedly, was an executable check that fails the build. If a contract
can't be expressed as a code check, it is an *unguarded gap* — named honestly, never papered
over with a doc.

## 4. Two modes + promotion (the fun/safe duality)

- **playtime** — fails open. Vague, generative, allowed to lie. For exploration. *This is the
  normal case — most of an app should stay playtime, because most of it is perceptually
  self-verifying: you can see if the UI is wrong.*
- **bigbrother** — fails closed. For the minority of capabilities where a silent violation is
  catastrophic and invisible (auth, anonymity, crypto, payment) — the places a human can't
  self-verify by looking.

**Promotion** (playtime → bigbrother) is the one explicit human act: not writing a spec, just
designating "this one is load-bearing now." That designation is sayable even when the full
spec is not — "this must actually be a mixnet" is articulable; the seventeen invariants are
not. The contracts come from the wrapped reference implementation; the human only points.

**The seam rule:** the boundary between a playtime block and a Big Brother block must itself
fail closed. A fuzzy block must not reach through and violate a neighbor's guarantee. (The
motivating failure: a discovery capability reached into a private-routing layer and stored a
peer address, silently destroying anonymity — the contract was real, lived only in prose, and
died when the context window compressed. The fix was a structural guard naming who may touch
internals, plus a behavioral guard asserting the invariant against actual output.)

## 5. The compiler adjacency

A block system is **a compiler of intent, not a palette of parts.** This is what separates it
from MIT-Scratch-style visual/block languages and why it escapes their ceiling:

- **Scratch's blocks are visible palette items a human assembles.** That model hits the
  expressiveness ceiling (the Deutsch limit, viscosity, the abstraction gradient) precisely
  *because a human is at the notation*, composing. Raising the floor lowers the ceiling.
- **These blocks are invisible and compiled-to.** The human stays at layer-7 intent; the
  system derives which load-bearing commitments the intent implies and composes the blocks
  beneath attention. Flip the human out of the composition seat and the expressiveness ceiling
  stops binding — it was a property of human-at-the-notation, not of blocks as such.

The deeper move, echoing the earlier "the path across the chasm isn't a bridge — it's a
compiler" framing: the user never names "TLS" or "indexer." Those fall out of the architecture
step, below attention. The system must **derive load-bearing commitments from vague intent** —
and it only needs to be sharp about the *finite* set of commitments where silent violation is
catastrophic (is this multi-user? does it touch money? does it carry an anonymity promise?),
staying stupid about the playtime 95%. You are not formalizing the whole intent. You are
pattern-matching the two or three commitments that have catastrophic invisible failure modes.

**The hard, mostly-unsolved piece** (the report's "intent formalization" grand challenge): the
*derivation* — recognizing from "people can post stuff" that you've crossed into multi-user-auth
territory. For an expert naming "mixnet," the tag is spoken. For the median user, the system
must *infer* the tag they'll never say. The guards are cheap; the trigger-recognition is the
value and the open problem.

## 6. The development-acceleration adjacency

The whole point is to stop re-deriving the same capability across every project. The acceleration
is **not** "the agent writes code faster" (that already exists). It is:

- **You stop paying the same discovery cost twice.** The hard-won contract for a capability is
  mined once and travels. The first project in a domain pays the expensive discovery; its output
  is the block (working impl + thin guard). Project N+1 inherits it and never re-derives it.
- **The reuse unit crosses languages.** A block can't be a library (libraries are language-bound).
  It is a *pattern + per-language realization*: the contract travels, the implementation is local
  (e.g. structured logging = `tracing` in Rust, `structlog` in Python, `pino` in TS). You reuse
  the through-line, not the code.
- **Substrate-adoption is the precondition, and that's the feature, not the bug.** This works on
  greenfield-on-substrate; it cannot retrofit a 10M-line legacy codebase, because that has no
  sealed boundaries to stand on. Requiring you build on the blocks is the price of admission and
  the source of the leverage — it's a "paved road" with teeth, where swapping X for Y is
  mechanical because everything sits on a substrate where Y is derivable.

The honest scope: most of an app stays playtime and self-verifying. The blocks earn their keep
at the handful of load-bearing seams a human can't eyeball — and in the boring, high-recurrence
plumbing rebuilt every time (logging, config, transport, persistence).

## 7. The four papers, mapped onto the block

This is the most important section: the blocks are not static. Agents improve them over time.
Each paper supplies one load-bearing piece of *how a block lives and gets better*.

### MOSS — enforcement is code, verified by replay against real evidence
Source-level, structural enforcement; the contract lives in the guard (code), not a doc, because
the text layer can only change what an agent *thinks*, not what the harness *decides*. An entire
class of failure is unreachable from prose. Verify by replay against real failure evidence, keep
a last-known-good, fail closed on a bad probe. → *the guard layer of every block.*

### AEvo — evolve the mechanism, not the output; protect the evaluator
When an agent discovers a new way to violate a block's contract, the response is to **tighten the
guard** (add the failing case), not patch one project — and to keep the rounds/budget/stopping
outside the agent so it can't quit early at the easy local optimum. Critically: the guard is the
**protected evaluator** — the agent being graded against it **may not edit it**. Agents may
*tighten* (strengthen) freely; *loosening* (remove a check, widen an allowlist, warn-instead-of-fail)
requires explicit human approval. The system can rewrite its own foundation, but only *uphill* —
strengthening is automatic, weakening needs a human. → *`evolution` + the protected boundary.*

### Meta-Agent — boundary contract for composition + 3-level failure attribution
A block declares an I/O contract at its boundary so blocks compose, and failures attribute to
**local** (this block), **upstream** (a block it depends on), or **structural** (the composition
itself is wrong) — so recovery is localized, not a full rebuild. This is inert with one block;
it only switches on at N≥2 (two blocks where one depends on the other). → *the interface layer.*

### FoT — federate insight across projects (the flywheel; the core motivation)
The answer to "why do my many repos share nothing." Each project distills what it learned about
a block into a **shared, capped, actively-merged** insight library (not a concatenated log — the
distillation *is* the compartmentalization, ~dozens of entries not hundreds). Insights travel
*across projects and languages* (code can't; insight can), and improve future projects — including
from *failed* projects, since noisy/failed traces still deposit value. The test of whether FoT is
real: **did a lesson cross a repo boundary without you copying it by hand?** A single notes file in
one repo is not FoT. The federation — A teaches, B inherits automatically — is the embodiment, and
it only has meaning at N≥2. → *the cross-project insight store.*

**Why two of four are "dormant at N=1":** MOSS and AEvo are *single-block* concepts (enforcement,
self-evolution) and embody immediately. Meta-Agent and FoT are *between-block / between-project*
concepts (composition, federation) and are structurally inert until a second block or second
project exists. Do not build their machinery speculatively on one block — that produces ceremony,
not value. They switch on when the second thing arrives.

## 8. The whole thing, one sentence

**A compiler of high-level intent into working software, where reusable capabilities ("blocks")
are composed invisibly beneath the user's attention; each block is an implemented capability plus
a thin fail-closed guard whose contract lives in code, not prose; most blocks stay playtime
(fail-open, exploratory) and a load-bearing minority are promoted to fail-closed by one explicit
human act; the system runs greenfield-on-substrate and inherits the four papers — MOSS (code
enforcement), AEvo (agents tighten the guard but cannot edit the evaluator), Meta-Agent (blocks
compose with attributed failures), and FoT (hard-won contracts and insights federate across
projects so each new project is cheaper than the last).**

It substitutes machine-checked, structurally-enforced contracts for the human perception that
forgiving creative tools (a shader graph, a node editor) get for free — so that code can become
as fluidly composable as those tools without inheriting their spaghetti, or the agent's habit of
taking the easy, spirit-violating path.

## 9. What is solved vs. open (honest ledger)

- **Solved / buildable now:** code-enforced guards that fail closed; the playtime/bigbrother
  duality and explicit promotion; per-language realization of a traveling contract; FoT-style
  cross-project federation (demonstrably real once two projects share a store); AEvo tighten-only
  self-evolution with a protected evaluator.
- **Open / the real risk:** *deriving* load-bearing commitments from vague intent (the trigger
  recognizer — the median user never says the tag); keeping each guard *cheap to author* (a guard
  per block must be an afternoon, not a research project, or the flywheel stalls); semantic (not
  just lexical) verification of "is this real / is this actually wired"; and, only if it ever
  matters, adversarial robustness (the current model assumes cooperative agents that get *lazy* or
  *drift* — entropy, not malice — which is a far easier bar and the right one for now).

The enemy was never an adversary. It was entropy: context windows compressing, guarantees rotting,
agents reaching for the easy path. Every block concept is an anti-entropy device, and that is the
correct, achievable standard to hold it to.
